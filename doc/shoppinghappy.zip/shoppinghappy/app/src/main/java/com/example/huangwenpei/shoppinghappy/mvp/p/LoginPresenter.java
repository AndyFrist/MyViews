package com.example.huangwenpei.shoppinghappy.mvp.p;

import com.alibaba.fastjson.JSONObject;
import com.example.huangwenpei.shoppinghappy.Bean.LoginBean;
import com.example.huangwenpei.shoppinghappy.Bean.LoginVerification;
import com.example.huangwenpei.shoppinghappy.Bean.RegisterBean;
import com.example.huangwenpei.shoppinghappy.mvp.m.MvpMainView;
import com.example.huangwenpei.shoppinghappy.utils.Constant;
import com.example.huangwenpei.shoppinghappy.utils.HttpUtil;
import com.example.huangwenpei.shoppinghappy.utils.LogUtil;

import java.util.Map;

/**
 * Created by huangwenpei
 * on 2018/6/13.
 * Description：
 */

public class LoginPresenter extends BasePresenter{

    public LoginPresenter(MvpMainView mvpView) {
        super(mvpView);
    }

    public void loginBypw(Map<String, String> map, final int requestCode) {

        if (map == null) {
            mvpView.showToast("参数不能为空");
        }
        mvpView.showLoading();

        HttpUtil httpUtil = new HttpUtil(new HttpUtil.HttpResponse() {
            @Override
            public void onSuccess(Object object) {
                String json = object.toString();

                final LoginBean loginBean = JSONObject.parseObject(json, LoginBean.class);
                LogUtil.d("Thread", Thread.currentThread().getName());


                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        mvpView.hidenLoading();
                        mvpView.updateView(loginBean,requestCode);
                    }
                });

            }

            @Override
            public void onFail(String error) {
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        mvpView.hidenLoading();
                    }
                });
            }
        });
        httpUtil.sendPostHttp(Constant.Login, map);

    }
    public void loginByLogin_Verification(Map<String, String> map, final int requestCode) {

        if (map == null) {
            mvpView.showToast("参数不能为空");
        }
        mvpView.showLoading();

        HttpUtil httpUtil = new HttpUtil(new HttpUtil.HttpResponse() {
            @Override
            public void onSuccess(Object object) {
                String json = object.toString();

                final LoginVerification loginBean = JSONObject.parseObject(json, LoginVerification.class);
                LogUtil.d("Thread", Thread.currentThread().getName());


                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        mvpView.hidenLoading();
                        mvpView.updateView(loginBean,requestCode);
                    }
                });

            }

            @Override
            public void onFail(String error) {
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        mvpView.hidenLoading();
                    }
                });
            }
        });
        httpUtil.sendPostHttp(Constant.Login_Verification, map);

    }
}
