package com.example.huangwenpei.shoppinghappy.mvp.activity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.huangwenpei.shoppinghappy.app.Myapp;
import com.example.huangwenpei.shoppinghappy.mvp.m.MvpMainView;
import com.example.huangwenpei.shoppinghappy.utils.ToastUtil;

/**
 * Created by huangwenpei
 * on 2018/6/10.
 */

public class BaseActivity extends AppCompatActivity implements MvpMainView {
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Myapp.activities.add(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Myapp.activities.remove(this);
    }

    @Override
    public void showLoading() {
        if (progressDialog == null) {
            progressDialog = ProgressDialog.show(this, "", "正在加载", true);
        } else if (progressDialog.isShowing()) {
            progressDialog.setTitle("");
            progressDialog.setMessage("正在查询...");
        }
    }

    @Override
    public void hidenLoading() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }

    @Override
    public void showToast(String msg) {
        ToastUtil.showToast(msg);
    }

    @Override
    public void updateView(Object obj, int requestCode) {

    }


}
