package com.example.huangwenpei.shoppinghappy.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.huangwenpei.shoppinghappy.R;


/**
 * 标题 2015.8.26 xuxiaopeng
 */
public class ViewTitleBar extends LinearLayout {
    private Drawable mSureImage, mCancleImage, mBackgroud,  mbackImage;
    private int titltColor, suretextcolor;

    private String mTitletext, mCancletext, mSuretext, mbackText;
    private boolean mSureimageshow, mSuretextshow, mCancleimageshow, mCancletextshow,  mback_ll_show;

    private ImageView imagev_title_cancle, imagev_title_sure;
    private TextView tv_title_sure, tv_title_cancle, tv_title_cenent_title;
    private RelativeLayout rl_activity_title_layout;
    private LinearLayout title_back_ll;
    private ImageView title_back_iv;
    private TextView title_back_tv;
    @SuppressLint("NewApi")
    public ViewTitleBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        LayoutInflater.from(context).inflate(R.layout.view_activity_title_layout, this, true);
        rl_activity_title_layout = (RelativeLayout) findViewById(R.id.rl_activity_title_layout);

        imagev_title_cancle = (ImageView) findViewById(R.id.imagev_title_cancle);
        imagev_title_sure = (ImageView) findViewById(R.id.imagev_title_sure);

        tv_title_cenent_title = (TextView) findViewById(R.id.tv_title_cenent_title);
        tv_title_sure = (TextView) findViewById(R.id.tv_title_sure);
        tv_title_cancle = (TextView) findViewById(R.id.tv_title_cancle);

        title_back_ll = (LinearLayout) findViewById(R.id.title_back_ll);
        title_back_iv = (ImageView) findViewById(R.id.title_back_iv);
        title_back_tv = (TextView) findViewById(R.id.title_back_tv);

        TypedArray array = context.obtainStyledAttributes(attrs, R.styleable.title_bar_attrs);

        mCancleImage = array.getDrawable(R.styleable.title_bar_attrs_cancelimage);
        mSureImage = array.getDrawable(R.styleable.title_bar_attrs_sureimage);
        mBackgroud = array.getDrawable(R.styleable.title_bar_attrs_backgroud);

        mTitletext = array.getString(R.styleable.title_bar_attrs_titletext);
        mCancletext = array.getString(R.styleable.title_bar_attrs_canceltext);
        mSuretext = array.getString(R.styleable.title_bar_attrs_suretext);

        mSureimageshow = array.getBoolean(R.styleable.title_bar_attrs_sureimageshow, false);
        mSuretextshow = array.getBoolean(R.styleable.title_bar_attrs_suretextshow, false);
        mCancleimageshow = array.getBoolean(R.styleable.title_bar_attrs_cancleimageshow, false);
        mCancletextshow = array.getBoolean(R.styleable.title_bar_attrs_cancletextshow, false);
        titltColor = array.getColor(R.styleable.title_bar_attrs_titlecolor, 0xffffffff);
        suretextcolor = array.getColor(R.styleable.title_bar_attrs_suretextcolor, 0xffffffff);

        mback_ll_show = array.getBoolean(R.styleable.title_bar_attrs_title_back_ll_show, false);
        mbackImage = array.getDrawable(R.styleable.title_bar_attrs_title_back_iv);
        mbackText = array.getString(R.styleable.title_bar_attrs_title_back_tv);

        tv_title_cenent_title.setText(mTitletext);

        if (mback_ll_show) {
            title_back_ll.setVisibility(VISIBLE);
            title_back_iv.setVisibility(VISIBLE);
            title_back_tv.setVisibility(INVISIBLE);
            if (!TextUtils.isEmpty(mbackText)) {
                title_back_tv.setText(mTitletext);
                title_back_tv.setTextColor(titltColor);
            }
            if (null != mbackImage) {
                title_back_iv.setImageDrawable(mbackImage);
            }
        }

        if (mCancleimageshow) {
            imagev_title_cancle.setVisibility(View.VISIBLE);
            imagev_title_cancle.setImageDrawable(mCancleImage);
        } else if (mCancletextshow) {
            tv_title_cancle.setVisibility(View.VISIBLE);
            tv_title_cancle.setText(mCancletext);
        }

        if (mSureimageshow) {
            imagev_title_sure.setVisibility(View.VISIBLE);
            imagev_title_sure.setImageDrawable(mSureImage);
        } else if (mSuretextshow) {
            tv_title_sure.setVisibility(View.VISIBLE);
            tv_title_sure.setText(mSuretext);
            tv_title_sure.setTextColor(suretextcolor);
        }

        if (null != mBackgroud) {
            rl_activity_title_layout.setBackgroundDrawable(mBackgroud);
        }
        array.recycle();
    }

    public void setBackVisible(boolean visible) {
        if (visible) {
            title_back_ll.setVisibility(VISIBLE);
            title_back_iv.setVisibility(VISIBLE);
            title_back_tv.setVisibility(INVISIBLE);
            if (!TextUtils.isEmpty(mbackText)) {
                title_back_tv.setText(mTitletext);
                title_back_tv.setTextColor(titltColor);
            }
            if (null != mbackImage) {
                title_back_iv.setImageDrawable(mbackImage);
            }
            setLeftImageVisible(INVISIBLE);
            setLeftTextVisible(INVISIBLE);
        } else {
            title_back_ll.setVisibility(GONE);
        }
    }

    public void setBackText(String backText) {
        title_back_tv.setText(mbackText);
    }

    public void setSureDisable(boolean disable) {
        if (null != tv_title_sure.getText()) {
            if (disable) {
                tv_title_sure.setVisibility(View.INVISIBLE);
            } else {
                tv_title_sure.setVisibility(View.VISIBLE);
            }
        }

        if (null != imagev_title_sure) {
            if (disable) {
                imagev_title_sure.setVisibility(View.INVISIBLE);
            } else {
                imagev_title_sure.setVisibility(View.VISIBLE);
            }
        }
    }

    /**
     * 设置左边按钮的点击事件
     */
    public void setCancleListen(OnClickListener listen) {
        if (View.VISIBLE == imagev_title_cancle.getVisibility()) {
            imagev_title_cancle.setOnClickListener(listen);
        }
        if (View.VISIBLE == tv_title_cancle.getVisibility()) {
            tv_title_cancle.setOnClickListener(listen);
        }
    }

    /**
     * 设置右边按钮的点击事件
     */
    public void setSureListen(OnClickListener listen) {
        if (View.VISIBLE == imagev_title_sure.getVisibility()) {
            imagev_title_sure.setOnClickListener(listen);
        }
        if (View.VISIBLE == tv_title_sure.getVisibility()) {
            // tv_title_sure.setTextColor(Color.WHITE);
            tv_title_sure.setOnClickListener(listen);
        }
    }

    /**
     * 设置回退点击事件
     */
    public void setBackllListen(OnClickListener listen) {
        setBackVisible(true);
        title_back_ll.setOnClickListener(listen);
    }

    /**
     * 获取右边按钮图片
     */
    public Drawable getSureImageViewDrawable() {
        if (View.VISIBLE == imagev_title_sure.getVisibility()) {
            return imagev_title_sure.getDrawable();
        }
        return null;
    }

    /**
     * 设置右边按钮图片资源
     */
    public void setSureImageViewDrawable(int drawableId) {
        imagev_title_sure.setVisibility(View.VISIBLE);
        tv_title_sure.setVisibility(View.GONE);
        imagev_title_sure.setImageResource(drawableId);
    }

    public void setTitle(String title) {
        if (null != tv_title_cenent_title) {
            tv_title_cenent_title.setText(title);
        }
    }

    public void setTitle(CharSequence text) {
        if (null != tv_title_cenent_title) {
            tv_title_cenent_title.setText(text);
        }
    }

    public void setTitle(int stringId) {
        if (null != tv_title_cenent_title) {
            tv_title_cenent_title.setText(stringId);
        }
    }

    public void setTitle(SpannableString spp) {
        if (null != tv_title_cenent_title) {
            tv_title_cenent_title.setText(spp);
        }
    }

    /**
     * 设置左边图片
     */
    public void setImagev_title_cancle(int drawable) {
        tv_title_cancle.setVisibility(View.INVISIBLE);
        this.imagev_title_cancle.setImageDrawable(getContext().getResources().getDrawable(drawable));
    }

    /**
     * 设置右边图片
     */
    public void setSureImage(int drawable) {
        tv_title_sure.setVisibility(View.INVISIBLE);
        imagev_title_sure.setVisibility(VISIBLE);
        this.imagev_title_sure.setImageDrawable(getContext().getResources().getDrawable(drawable));
    }

    public ImageView getRightImageView() {
        return imagev_title_sure;
    }


    public void setLeftImageVisible(int visibility) {
        imagev_title_cancle.setVisibility(visibility);
        if (visibility == View.VISIBLE) {
            setLeftTextVisible(INVISIBLE);
            setBackVisible(false);
        }
    }

    public void setLeftTextVisible(int visibility) {
        tv_title_cancle.setVisibility(visibility);
        if (visibility == View.VISIBLE) {
            setLeftImageVisible(INVISIBLE);
            setBackVisible(false);
        }
    }

    public void setSureText(String text) {
        if (!TextUtils.isEmpty(text)) {
            imagev_title_sure.setVisibility(View.GONE);
            tv_title_sure.setVisibility(View.VISIBLE);
            tv_title_sure.setText(text);
            tv_title_sure.setTextColor(Color.WHITE);
        }
    }

    public void setCancleText(String text) {
        if (!TextUtils.isEmpty(text)) {
            imagev_title_cancle.setVisibility(View.GONE);
            tv_title_cancle.setVisibility(View.VISIBLE);
            tv_title_cancle.setText(text);
            tv_title_cancle.setTextColor(Color.WHITE);

            setBackVisible(false);
        }
    }

    public void setSureTextColor(int i) {
        tv_title_sure.setEnabled(true);
        tv_title_sure.setVisibility(View.VISIBLE);
        tv_title_sure.setTextColor(i);
    }
}
