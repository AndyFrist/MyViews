package com.example.huangwenpei.shoppinghappy.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.huangwenpei.shoppinghappy.R;


public class BottomBar extends LinearLayout implements OnClickListener {

    public static final int TAB_0 = 0;
    public static final int TAB_1 = 1;
    public static final int TAB_2 = 2;
    public static final int TAB_3 = 3;
    public static final int TAB_4 = 4;

    private int mCurrentTab = -1;

    private TextView mTvTab0, mTvTab1, mTvTab2, mTvTab3,mTvTab4;
    private ImageView mIvTab0, mIvTab1, mIvTab2, mIvTab3,mIvTab4;

    private BottomBarListener mListener;

    public BottomBar(Context context) {
        this(context, null);
    }

    public BottomBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.view_bottombar, this, true);

        mTvTab0 = (TextView) findViewById(R.id.tvTab0);
        mTvTab1 = (TextView) findViewById(R.id.tvTab1);
        mTvTab2 = (TextView) findViewById(R.id.tvTab2);
        mTvTab3 = (TextView) findViewById(R.id.tvTab3);
        mTvTab4 = (TextView) findViewById(R.id.tvTab4);

        mIvTab0 = (ImageView) findViewById(R.id.ivTab0);
        mIvTab1 = (ImageView) findViewById(R.id.ivTab1);
        mIvTab2 = (ImageView) findViewById(R.id.ivTab2);
        mIvTab3 = (ImageView) findViewById(R.id.ivTab3);
        mIvTab4 = (ImageView) findViewById(R.id.ivTab4);

        findViewById(R.id.llTab0).setOnClickListener(this);
        findViewById(R.id.llTab1).setOnClickListener(this);
        findViewById(R.id.llTab2).setOnClickListener(this);
        findViewById(R.id.llTab3).setOnClickListener(this);
        findViewById(R.id.llTab4).setOnClickListener(this);
    }

    public void setBottomBarTab(int index) {
        setSelection(index);
    }

    private void setSelection(int index) {
        if (mCurrentTab == index) {
            return;
        }
        if (mCurrentTab != -1) {
            changeState(mCurrentTab, true);
        }
        mCurrentTab = index;
        changeState(mCurrentTab, false);
    }

    private void changeState(int selection, boolean isClear) {
        switch (selection) {
            case TAB_0:
                setTab(mTvTab0, mIvTab0, isClear ? R.mipmap.icon_homepage_normal : R.mipmap.icon_homepage_selected, isClear);
                break;
            case TAB_1:
                setTab(mTvTab1, mIvTab1, isClear ? R.mipmap.icon_workbench_normal : R.mipmap.icon_workbench_selected, isClear);
                break;
            case TAB_2:
                setTab(mTvTab2, mIvTab2, isClear ? R.mipmap.icon_message_normal : R.mipmap.icon_message_selected, isClear);
                break;
            case TAB_3:
                setTab(mTvTab3, mIvTab3, isClear ? R.mipmap.icon_myself_normal : R.mipmap.icon_myself_selected, isClear);
                break;
            case TAB_4:
                setTab(mTvTab4, mIvTab4, isClear ? R.mipmap.icon_myself_normal : R.mipmap.icon_myself_selected, isClear);
                break;
            default:
                break;
        }

    }

    private void setTab(TextView tv, ImageView iv, int imgId, boolean isClear) {
        iv.setImageResource(imgId);
        if (isClear) {
            tv.setTextColor(getResources().getColor(R.color.black_text));
        } else {
            tv.setTextColor(getResources().getColor(R.color.color1));
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.llTab0:
                onClickBottom(v, TAB_0);
                break;
            case R.id.llTab1:
                onClickBottom(v, TAB_1);
                break;
            case R.id.llTab2:
                onClickBottom(v, TAB_2);
                break;
            case R.id.llTab3:
                onClickBottom(v, TAB_3);
                break;
            case R.id.llTab4:
                onClickBottom(v, TAB_4);
                break;
            default:
                break;
        }
    }

    public void onClickBottom(View v, int index) {

        if (mListener != null) {
            mListener.onClickBottom(v, index);
        } else {
            switch (v.getId()) {
                case R.id.llTab0:

                    break;
                case R.id.llTab1:

                    break;
                case R.id.llTab2:

                    break;
                case R.id.llTab3:

                    break;
                case R.id.llTab4:

                    break;
            }
        }
    }

    public void setBottomBarListener(BottomBarListener listener) {
        this.mListener = listener;
    }

    public interface BottomBarListener {
        void onClickBottom(View v, int index);
    }
}
