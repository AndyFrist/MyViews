package com.example.huangwenpei.shoppinghappy.mvp.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.huangwenpei.shoppinghappy.Bean.RegisterBean;
import com.example.huangwenpei.shoppinghappy.R;
import com.example.huangwenpei.shoppinghappy.mvp.p.RegisterPresenter;
import com.example.huangwenpei.shoppinghappy.utils.Constant;
import com.example.huangwenpei.shoppinghappy.utils.HttpUtil;
import com.example.huangwenpei.shoppinghappy.utils.LogUtil;
import com.example.huangwenpei.shoppinghappy.utils.ToastUtil;
import com.example.huangwenpei.shoppinghappy.view.ViewTitleBar;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends BaseActivity implements View.OnClickListener {
    private ViewTitleBar title_register;
    private EditText edit_referees;
    private EditText edit_phone;
    private EditText edit_password;
    private EditText edit_pwsure;
    private TextView register;
    private TextView login;

    private String referees;
    private String phone;
    private String password;
    private String pwsure;

    RegisterPresenter presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regust);
        initView();
    }

    private void initView() {
        title_register = findViewById(R.id.title_register);
        edit_referees = findViewById(R.id.edit_referees);
        edit_phone = findViewById(R.id.edit_phone);
        edit_password = findViewById(R.id.edit_password);
        edit_pwsure = findViewById(R.id.edit_pwsure);
        register = findViewById(R.id.register);
        register.setOnClickListener(this);
        login = findViewById(R.id.login);
        login.setOnClickListener(this);
        title_register.setBackllListen(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        presenter = new RegisterPresenter(this);
        presenter.attach(this);

    }


    @Override
    public void onClick(View view) {
        if (register == view) {
            referees = edit_referees.getText().toString().trim();
            phone = edit_phone.getText().toString().trim();
            password = edit_password.getText().toString().trim();
            pwsure = edit_pwsure.getText().toString().trim();

            if (TextUtils.isEmpty(referees)) {
                ToastUtil.showToast("请填写推荐人");
                return;
            }

            if (TextUtils.isEmpty(phone)) {
                ToastUtil.showToast("请填手机号");
                return;
            }
            if (TextUtils.isEmpty(password)) {
                ToastUtil.showToast("请填写密码");
                return;
            }
            if (!password.equals(pwsure)) {
                ToastUtil.showToast("两次密码不一致");
                return;
            }

            LogUtil.d("Thread", Thread.currentThread().getName());

            Map<String, String> map = new HashMap<>();
            map.put("mobile", phone);
            map.put("verificationCode", "1234");
            map.put("qrCode", "string");
            map.put("password", "1234");
            presenter.register(map, 1);
        }

        if (login == view) {
            startActivity(new Intent(this, LoginActivity.class));
        }
    }

    @Override
    public void updateView(Object obj, int requestCode) {
        super.updateView(obj, requestCode);
        if (requestCode == 1) {
            RegisterBean registerBean = (RegisterBean) obj;
            showToast(registerBean.getMessage());
        }
    }
}
