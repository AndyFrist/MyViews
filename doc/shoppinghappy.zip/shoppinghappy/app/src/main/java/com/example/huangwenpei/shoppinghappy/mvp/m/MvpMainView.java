package com.example.huangwenpei.shoppinghappy.mvp.m;

/**
 * Created by ex-xuxiaopeng001
 * on 2018/4/26.
 */

public interface MvpMainView extends MvpLodingView{
    void showToast(String msg);

    void updateView(Object obj, int requestCode);
}
