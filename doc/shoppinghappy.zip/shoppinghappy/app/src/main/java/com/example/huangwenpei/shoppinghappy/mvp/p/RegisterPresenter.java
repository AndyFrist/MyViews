package com.example.huangwenpei.shoppinghappy.mvp.p;


import com.alibaba.fastjson.JSONObject;
import com.example.huangwenpei.shoppinghappy.Bean.RegisterBean;
import com.example.huangwenpei.shoppinghappy.mvp.m.MvpMainView;
import com.example.huangwenpei.shoppinghappy.utils.Constant;
import com.example.huangwenpei.shoppinghappy.utils.HttpUtil;
import com.example.huangwenpei.shoppinghappy.utils.LogUtil;

import java.util.Map;

/**
 * Created by huangwenpei
 * on 2018/6/13.
 */

public class RegisterPresenter extends BasePresenter {
    public RegisterPresenter(MvpMainView mvpView) {
        super(mvpView);
    }


    public void register(Map<String, String> map,final int requestCode) {

        if (map == null) {
            mvpView.showToast("参数不能为空");
        }
        mvpView.showLoading();

        HttpUtil httpUtil = new HttpUtil(new HttpUtil.HttpResponse() {
            @Override
            public void onSuccess(Object object) {
                String json = object.toString();

                final RegisterBean registerBean = JSONObject.parseObject(json, RegisterBean.class);
                LogUtil.d("Thread", Thread.currentThread().getName());


                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        mvpView.hidenLoading();
                        mvpView.updateView(registerBean,requestCode);
                    }
                });

            }

            @Override
            public void onFail(String error) {

            }
        });
        httpUtil.sendPostHttp(Constant.Regirst, map);

    }
}
