package com.example.huangwenpei.shoppinghappy.Bean;

/**
 * Created by xuxiaopeng
 * on 2018/6/13.
 * Description：
 */

public class LoginBean {


    /**
     * resultCode : 202
     * message : 用户登录成功
     * data : null
     */

    private int resultCode;
    private String message;
    private Object data;

    public int getResultCode() {
        return resultCode;
    }

    public void setResultCode(int resultCode) {
        this.resultCode = resultCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}
