package com.example.huangwenpei.shoppinghappy.mvp.p;

import android.content.Context;
import android.os.Looper;

import com.example.huangwenpei.shoppinghappy.mvp.m.MvpMainView;

/**
 * Created by ex-xuxiaopeng001
 * on 2018/4/26.
 */

public class BasePresenter {

    MvpMainView mvpView;
    //全局handler
    android.os.Handler mHandler = new android.os.Handler(Looper.getMainLooper());


    public BasePresenter(MvpMainView mvpView) {
        this.mvpView = mvpView;
    }

    Context mContext;

    public void attach(Context context) {
        mContext = context;
    }

    public void onPause() {
    }

    public void onResume() {
    }

    public void onDestroy() {
        mContext = null;
    }

}
