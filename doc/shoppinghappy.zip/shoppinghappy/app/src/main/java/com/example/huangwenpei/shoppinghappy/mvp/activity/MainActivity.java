package com.example.huangwenpei.shoppinghappy.mvp.activity;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.util.SparseArrayCompat;
import android.view.View;

import com.example.huangwenpei.shoppinghappy.R;
import com.example.huangwenpei.shoppinghappy.fragment.FindFragment;
import com.example.huangwenpei.shoppinghappy.fragment.HomeFragment;
import com.example.huangwenpei.shoppinghappy.fragment.MarketFragment;
import com.example.huangwenpei.shoppinghappy.fragment.MineFragment;
import com.example.huangwenpei.shoppinghappy.fragment.ZoneFragment;
import com.example.huangwenpei.shoppinghappy.view.BottomBar;
import com.example.huangwenpei.shoppinghappy.view.ViewTitleBar;

public class MainActivity extends BaseActivity {
    private static final String[] FRAGMENT_TAG = {"frag0", "frag1", "frag2", "frag3", "frag4"};
    private ViewTitleBar title_main;
    private BottomBar mBottomBar;
    private android.support.v4.app.FragmentManager mFragmentManager;
    private SparseArrayCompat<Fragment> mCacheFragments = new SparseArrayCompat<>();
    private HomeFragment mFragmentA = null;
    private Fragment mWorkbenchFragment = null;
    private Fragment mFragmentC = null;
    private Fragment mFragmentD = null;
    private Fragment mFragmentE = null;

    public int mCurrentIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        mFragmentManager = getSupportFragmentManager();
        if (savedInstanceState != null) {
            mFragmentA= (HomeFragment) mFragmentManager.findFragmentByTag(FRAGMENT_TAG[0]);
            mWorkbenchFragment = mFragmentManager.findFragmentByTag(FRAGMENT_TAG[1]);
            mFragmentC =  mFragmentManager.findFragmentByTag(FRAGMENT_TAG[2]);
            mFragmentD=  mFragmentManager.findFragmentByTag(FRAGMENT_TAG[3]);
            mFragmentE=  mFragmentManager.findFragmentByTag(FRAGMENT_TAG[4]);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initFragments();
    }



    private void initView() {
        mBottomBar = (BottomBar) findViewById(R.id.bottomBar);
        mBottomBar.setBottomBarListener(new BottomBar.BottomBarListener() {
            @Override
            public void onClickBottom(View v, int index) {
                setTabSelection(index);
            }
        });
        title_main = findViewById(R.id.title_main);

    }

    public void setTitle(String title) {
        title_main.setTitle(title);
    }
    private void initFragments() {
        mFragmentManager = getSupportFragmentManager();
        setTabSelection(BottomBar.TAB_0);
    }

    private void setTabSelection(int index) {
        if (mCurrentIndex == index) {
            return;
        }

        if( index == 0 ){
            if( null != mFragmentA ) {
            }
        }

        FragmentTransaction transaction = mFragmentManager.beginTransaction();
        hideFragments(transaction);

        mCurrentIndex = index;
        switch (index) {
            case BottomBar.TAB_0:
                if (mFragmentA == null) {
                    mFragmentA = new HomeFragment();
                    transaction.add(R.id.flContent, mFragmentA, FRAGMENT_TAG[mCurrentIndex]);
                    mCacheFragments.put(mCurrentIndex, mFragmentA);
                }else {
                    hideFragments(transaction);
                }

                transaction.show(mFragmentA);
                mBottomBar.setBottomBarTab(BottomBar.TAB_0);
                setTitle("首页");
                break;
            case BottomBar.TAB_1:
                if (mWorkbenchFragment == null) {
                    mWorkbenchFragment = new ZoneFragment();
                    transaction.add(R.id.flContent, mWorkbenchFragment, FRAGMENT_TAG[mCurrentIndex]);
                    mCacheFragments.put(mCurrentIndex, mWorkbenchFragment);
                }else {
                    hideFragments(transaction);
                }

                transaction.show(mWorkbenchFragment);
                mBottomBar.setBottomBarTab(BottomBar.TAB_1);
                setTitle("专区");
                break;
            case BottomBar.TAB_2:
                if (mFragmentC == null) {
                    mFragmentC = new FindFragment();
                    transaction.add(R.id.flContent, mFragmentC, FRAGMENT_TAG[mCurrentIndex]);
                    mCacheFragments.put(mCurrentIndex, mFragmentC);
                }else {
                    hideFragments(transaction);
                }

                transaction.show(mFragmentC);
                mBottomBar.setBottomBarTab(BottomBar.TAB_2);
                setTitle("发现");
                break;
            case BottomBar.TAB_3:
                if (mFragmentD == null) {
                    mFragmentD = new MarketFragment();
                    transaction.add(R.id.flContent, mFragmentD, FRAGMENT_TAG[mCurrentIndex]);
                    mCacheFragments.put(mCurrentIndex, mFragmentD);
                }else {
                    hideFragments(transaction);
                }

                transaction.show(mFragmentD);
                mBottomBar.setBottomBarTab(BottomBar.TAB_3);
                setTitle("金豆市场");
                break;
            case BottomBar.TAB_4:
                if (mFragmentE == null) {
                    mFragmentE = new MineFragment();
                    transaction.add(R.id.flContent, mFragmentE, FRAGMENT_TAG[mCurrentIndex]);
                    mCacheFragments.put(mCurrentIndex, mFragmentE);
                }else {
                    hideFragments(transaction);
                }

                transaction.show(mFragmentE);
                mBottomBar.setBottomBarTab(BottomBar.TAB_4);
                setTitle("我的");
                break;
            default:
                break;
        }
        transaction.commitAllowingStateLoss();
    }

    private void hideFragments(FragmentTransaction transaction) {
        if (mFragmentA != null) {
            transaction.hide(mFragmentA);
        }
        if (mWorkbenchFragment != null) {
            transaction.hide(mWorkbenchFragment);
        }
        if (mFragmentC != null) {
            transaction.hide(mFragmentC);
        }
        if (mFragmentD != null) {
            transaction.hide(mFragmentD);
        }
        if (mFragmentE != null) {
            transaction.hide(mFragmentE);
        }
    }

}
