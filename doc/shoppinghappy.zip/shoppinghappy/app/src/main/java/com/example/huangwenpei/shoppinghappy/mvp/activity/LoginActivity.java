package com.example.huangwenpei.shoppinghappy.mvp.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.huangwenpei.shoppinghappy.Bean.LoginBean;
import com.example.huangwenpei.shoppinghappy.R;
import com.example.huangwenpei.shoppinghappy.mvp.p.LoginPresenter;
import com.example.huangwenpei.shoppinghappy.utils.ToastUtil;
import com.example.huangwenpei.shoppinghappy.view.ViewTitleBar;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends BaseActivity implements View.OnClickListener {

    private ViewTitleBar title_login;
    private TextView password_login;
    private TextView check_login;
    private TextView login;
    private TextView register;
    private EditText edit_phone;
    private TextView edit_password;
    private String phone;
    private String password;
    LoginPresenter presenter;
    private int requestCode = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initView();

    }

    private void initView() {
        title_login = findViewById(R.id.title_login);
        password_login = findViewById(R.id.password_login);
        password_login.setOnClickListener(this);
        check_login = findViewById(R.id.check_login);
        check_login.setOnClickListener(this);
        login = findViewById(R.id.login);
        login.setOnClickListener(this);
        register = findViewById(R.id.register);
        register.setOnClickListener(this);
        edit_phone = findViewById(R.id.edit_phone);
        edit_password = findViewById(R.id.edit_password);
        title_login.setBackllListen(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        presenter = new LoginPresenter(this);
        presenter.attach(this);

    }

    @Override
    public void onClick(View view) {
        if (view == password_login) {
            ToastUtil.showToast("密码登录");
            password_login.setTextColor(getResources().getColor(R.color.colorPrimary));
            check_login.setTextColor(getResources().getColor(R.color.gray));
            requestCode = 1;

        }

        if (view == check_login) {
            ToastUtil.showToast("验证码登录");
            password_login.setTextColor(getResources().getColor(R.color.gray));
            check_login.setTextColor(getResources().getColor(R.color.colorPrimary));
            requestCode = 2;
        }
        if (view == login) {
            phone = edit_phone.getText().toString().trim();
            password = edit_password.getText().toString().trim();
            if (TextUtils.isEmpty(phone)) {
                ToastUtil.showToast("请填写手机号码");
                return;
            }
            if (TextUtils.isEmpty(password)) {
                ToastUtil.showToast("请输入密码");
                return;
            }
            if (requestCode == 1) {
                Map<String, String> map = new HashMap<>();
                map.put("mobile", phone);
                map.put("password", "1234");
                presenter.loginBypw(map, 1);
            } else if (requestCode == 2) {
                Map<String, String> map = new HashMap<>();
                map.put("mobile", phone);
                map.put("verificationCode", "1234");
                presenter.loginByLogin_Verification(map, 2);
            }
        }

        if (view == register) {
            startActivity(new Intent(this, RegisterActivity.class));
        }
    }

    @Override
    public void updateView(Object obj, int requestCode) {
        super.updateView(obj, requestCode);
        if (requestCode == 1) {
            LoginBean loginBean = (LoginBean) obj;
            if (loginBean != null) {
                showToast(loginBean.getMessage());
                startActivity(new Intent(this, MainActivity.class));
            }
        } else if (requestCode == 2) {
            LoginBean loginBean = (LoginBean) obj;
            if (loginBean != null) {
                showToast(loginBean.getMessage());
                startActivity(new Intent(this, MainActivity.class));
            }
        }
    }
}
