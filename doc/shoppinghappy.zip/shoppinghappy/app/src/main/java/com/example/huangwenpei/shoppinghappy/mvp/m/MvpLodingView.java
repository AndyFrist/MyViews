package com.example.huangwenpei.shoppinghappy.mvp.m;

/**
 * Created by ex-xuxiaopeng001
 * on 2018/4/26.
 */

public interface MvpLodingView {
    void showLoading();
    void hidenLoading();
}
