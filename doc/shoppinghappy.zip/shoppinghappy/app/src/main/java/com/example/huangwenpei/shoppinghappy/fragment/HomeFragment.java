package com.example.huangwenpei.shoppinghappy.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.example.huangwenpei.shoppinghappy.R;
import com.example.huangwenpei.shoppinghappy.mvp.activity.MainActivity;


public class HomeFragment extends Fragment {

    private MainActivity mainActivity;
    private WebView home_webview;
    public HomeFragment() {

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mainActivity = (MainActivity) context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        home_webview = view.findViewById(R.id.home_webview);
        home_webview.getSettings().setJavaScriptEnabled(true);
        home_webview.loadUrl("https://h5.m.taobao.com/");
        home_webview.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {


                return super.shouldOverrideUrlLoading(view, request);
            }
        });

        home_webview.setWebChromeClient(new WebChromeClient(){
            @Override
            public void onReceivedTitle(WebView view, String title) {
                super.onReceivedTitle(view, title);
                mainActivity.setTitle(title);

            }
        });
        return view;
    }

}
