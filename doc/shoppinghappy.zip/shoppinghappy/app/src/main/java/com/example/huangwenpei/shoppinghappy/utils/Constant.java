package com.example.huangwenpei.shoppinghappy.utils;

/**
 * Created by huangwenpei
 * on 2018/6/12.
 */

public class Constant {
    public static final String BaseURL = "http://zhanghaiguo.wicp.net:53874/";
    public static final String Regirst = BaseURL + "user/v1/register";
    public static final String Login = BaseURL + "user/v1/loginByPassword";
    public static final String Login_Verification = BaseURL + "user/v1/loginByVerification";
}
