package com.example.huangwenpei.shoppinghappy.app;

import android.app.Activity;
import android.app.Application;
import android.content.Context;

import java.util.ArrayList;

/**
 * Created by huangwenpei
 * on 2018/6/10.
 */

public class Myapp extends Application {

    public static Application application = null;
    public static ArrayList<Activity> activities = new ArrayList<>();

    @Override
    public void onCreate() {
        super.onCreate();
        application = this;
        appContext = getApplicationContext();
    }

    private static Context appContext;

    public static Context getContext() {
        return appContext;
    }
}
