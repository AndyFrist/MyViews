package com.example.huangwenpei.shoppinghappy.mvp.activity;

import android.content.Intent;
import android.os.Handler;
import android.os.Bundle;
import android.widget.TextView;

import com.example.huangwenpei.shoppinghappy.R;

public class StartActivity extends BaseActivity {

    private TextView times;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        times = findViewById(R.id.times);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
                startActivity(new Intent(StartActivity.this, RegisterActivity.class));
//                startActivity(new Intent(StartActivity.this, MainActivity.class));
            }
        }, 1000);
    }
}
